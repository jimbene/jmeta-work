<?php

    $title = '로그인';
    include_once ('../templates/header.php');
?>
    <h2></h2>
<?php
    include_once ('../templates/footer.php');
?> 