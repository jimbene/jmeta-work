<?php

    $title = 'job in meta | 잡인메타';
    include_once ('templates/header.php');
?>
    <input type="search" id="" name="" placeholder="">

    <img src="images/temp/tp_main-bnr-01.png" alt="이력서에 희망근무조건을 등록하면 맞춤 공고를 보여드려요">
    <h2>ddddsg</h2>
    <a href="../page/login.php">로그인하기</a>
<?php
    include_once ('templates/footer.php');
?>